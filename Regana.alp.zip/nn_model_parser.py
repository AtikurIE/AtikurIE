#!/usr/bin/env python
# coding: utf-8

# In[5]:



import numpy as np
from sklearn.ensemble import RandomForestRegressor
from collections import deque

class classifier:
    ''' A simple class to easily query the neural networks from inside AnyLogic using Pypeline '''
    def __init__(self):
        # load the LOS model
        self.RandomForestRegressor = ("trained_random_forest_model.h5")
       
    def RandomForestRegressor (self, patient_data):
        ''' Given the (1, 21) array of patient data, predict the length of stay (days) '''
        # convert default list to numpy array
        patient_array = np.array(patient_data)
        
        # query the neural network for the length of stay
        prediction = self.trained_random_forest_model.predict(patient_array)
        return prediction[0][0]
        
